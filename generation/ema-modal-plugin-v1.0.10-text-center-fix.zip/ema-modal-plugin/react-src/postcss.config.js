export default {
  plugins: {
    autoprefixer: {},
  },
}; 