import React, { useState, useRef, useEffect } from 'react';

interface TooltipProviderProps {
    children: React.ReactNode;
    delayDuration?: number;
}

export const TooltipProvider: React.FC<TooltipProviderProps> = ({
    children
}) => {
    return <>{children}</>;
};

interface TooltipProps {
    children: React.ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
}

export const Tooltip: React.FC<TooltipProps> = ({
    children
}) => {
    return <div className="relative inline-block">{children}</div>;
};

interface TooltipTriggerProps {
    children: React.ReactNode;
    asChild?: boolean;
}

export const TooltipTrigger: React.FC<TooltipTriggerProps> = ({
    children,
    asChild = false
}) => {
    if (asChild && React.isValidElement(children)) {
        return children;
    }

    return <>{children}</>;
};

interface TooltipContentProps {
    children: React.ReactNode;
    className?: string;
    side?: 'top' | 'bottom' | 'left' | 'right';
    align?: 'start' | 'center' | 'end';
}

export const TooltipContent: React.FC<TooltipContentProps> = ({
    children,
    className = '',
    side = 'top',
    align = 'center'
}) => {
    const sideClasses = {
        top: 'bottom-full mb-2',
        bottom: 'top-full mt-2',
        left: 'right-full mr-2',
        right: 'left-full ml-2',
    };

    const alignClasses = {
        start: 'left-0',
        center: 'left-1/2 transform -translate-x-1/2',
        end: 'right-0',
    };

    return (
        <div
            className={`absolute z-50 rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white shadow-md ${sideClasses[side]} ${alignClasses[align]} ${className}`}
            role="tooltip"
        >
            {children}
        </div>
    );
}; 