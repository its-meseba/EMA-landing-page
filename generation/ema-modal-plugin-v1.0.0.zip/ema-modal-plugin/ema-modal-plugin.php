<?php
/**
 * Plugin Name:       EMA Modal Plugin
 * Description:       Integrates the interactive EMA Modal into any WordPress site.
 * Version:           1.0.0
 * Author:            EMA Team
 * Author URI:        https://ema.ai
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ema-modal
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// 1. Create the Admin Menu item
function ema_modal_options_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'ema_modal_options' );
            do_settings_sections( 'ema_modal' );
            submit_button( 'Save Settings' );
            ?>
        </form>
        <div style="margin-top: 20px; padding: 15px; background: #f0f8ff; border-left: 4px solid #0066ff;">
            <h3>How to Use:</h3>
            <p>1. Enter your EMA URL (provided by EMA team)</p>
            <p>2. Customize the theme color to match your brand</p>
            <p>3. Save settings - the modal will automatically appear on your website</p>
            <p>4. Visitors can click the floating button to interact with EMA</p>
        </div>
    </div>
    <?php
}

function ema_modal_options_page() {
    add_options_page(
        'EMA Modal Settings',
        'EMA Modal',
        'manage_options',
        'ema_modal',
        'ema_modal_options_page_html'
    );
}
add_action( 'admin_menu', 'ema_modal_options_page' );

// 2. Register Settings, Sections, and Fields
function ema_modal_register_settings() {
    register_setting( 'ema_modal_options', 'ema_modal_settings' );

    add_settings_section(
        'ema_modal_section_main',
        'Main Configuration',
        'ema_modal_section_main_cb',
        'ema_modal'
    );

    add_settings_field(
        'ema_modal_field_url',
        'EMA URL',
        'ema_modal_field_url_cb',
        'ema_modal',
        'ema_modal_section_main'
    );
    
    add_settings_field(
        'ema_modal_field_themecolor',
        'Theme Color',
        'ema_modal_field_color_cb',
        'ema_modal',
        'ema_modal_section_main'
    );

    add_settings_field(
        'ema_modal_field_title',
        'Modal Title',
        'ema_modal_field_title_cb',
        'ema_modal',
        'ema_modal_section_main'
    );

    add_settings_field(
        'ema_modal_field_subtitle',
        'Modal Subtitle',
        'ema_modal_field_subtitle_cb',
        'ema_modal',
        'ema_modal_section_main'
    );

    add_settings_field(
        'ema_modal_field_brandname',
        'Brand Name',
        'ema_modal_field_brandname_cb',
        'ema_modal',
        'ema_modal_section_main'
    );
}
add_action( 'admin_init', 'ema_modal_register_settings' );

function ema_modal_section_main_cb() {
    echo '<p>Configure your EMA modal settings below. Make sure to get your EMA URL from the EMA team.</p>';
}

function ema_modal_field_url_cb() {
    $options = get_option( 'ema_modal_settings' );
    $url = isset( $options['ema_url'] ) ? esc_attr( $options['ema_url'] ) : '';
    echo '<input type="url" name="ema_modal_settings[ema_url]" value="' . $url . '" class="regular-text" placeholder="https://your-ema-instance.com" required>';
    echo '<p class="description">Enter the EMA URL provided by your EMA team.</p>';
}

function ema_modal_field_color_cb() {
    $options = get_option( 'ema_modal_settings' );
    $color = isset( $options['theme_color'] ) ? esc_attr( $options['theme_color'] ) : '#0066ff';
    echo '<input type="color" name="ema_modal_settings[theme_color]" value="' . $color . '">';
    echo '<p class="description">Choose a color that matches your brand.</p>';
}

function ema_modal_field_title_cb() {
    $options = get_option( 'ema_modal_settings' );
    $title = isset( $options['title'] ) ? esc_attr( $options['title'] ) : 'EMA – Etkileşimli Müşteri Asistanı';
    echo '<input type="text" name="ema_modal_settings[title]" value="' . $title . '" class="regular-text">';
    echo '<p class="description">The main title shown in the modal.</p>';
}

function ema_modal_field_subtitle_cb() {
    $options = get_option( 'ema_modal_settings' );
    $subtitle = isset( $options['subtitle'] ) ? esc_attr( $options['subtitle'] ) : 'Ürünleri bulmanın, sorularınızı sormanın en kolay yolu';
    echo '<input type="text" name="ema_modal_settings[subtitle]" value="' . $subtitle . '" class="regular-text">';
    echo '<p class="description">The subtitle shown in the modal. Use {{brand}} to insert your brand name.</p>';
}

function ema_modal_field_brandname_cb() {
    $options = get_option( 'ema_modal_settings' );
    $brandname = isset( $options['brand_name'] ) ? esc_attr( $options['brand_name'] ) : '';
    echo '<input type="text" name="ema_modal_settings[brand_name]" value="' . $brandname . '" class="regular-text">';
    echo '<p class="description">Your brand name (will replace {{brand}} in subtitle).</p>';
}

// 3. Enqueue Scripts and Styles for the Frontend
function ema_modal_enqueue_assets() {
    // Only enqueue on the public-facing site, not in the admin area
    if ( is_admin() ) {
        return;
    }

    $asset_path = plugin_dir_path( __FILE__ ) . 'dist/';
    $asset_uri = plugin_dir_url( __FILE__ ) . 'dist/';

    // Check if assets exist
    if ( ! file_exists( $asset_path . 'ema-modal.js' ) ) {
        return;
    }

    // Enqueue CSS
    if ( file_exists( $asset_path . 'ema-modal.css' ) ) {
        wp_enqueue_style(
            'ema-modal-style',
            $asset_uri . 'ema-modal.css',
            [],
            filemtime( $asset_path . 'ema-modal.css' )
        );
    }

    // Enqueue JS
    wp_enqueue_script(
        'ema-modal-script',
        $asset_uri . 'ema-modal.js',
        [],
        filemtime( $asset_path . 'ema-modal.js' ),
        true // Load in footer
    );

    // Get saved settings and pass them to our script
    $settings = get_option( 'ema_modal_settings' );
    $props = [
        'emaUrl'     => isset( $settings['ema_url'] ) ? $settings['ema_url'] : '',
        'themeColor' => isset( $settings['theme_color'] ) ? $settings['theme_color'] : '#0066ff',
        'title'      => isset( $settings['title'] ) ? $settings['title'] : 'EMA – Etkileşimli Müşteri Asistanı',
        'subtitle'   => isset( $settings['subtitle'] ) ? $settings['subtitle'] : 'Ürünleri bulmanın, sorularınızı sormanın en kolay yolu',
        'brandName'  => isset( $settings['brand_name'] ) ? $settings['brand_name'] : '',
        'ctaLabel'   => 'EMA yı Başlat',
        'socialProof' => '+1 200 kişi bugün EMA yı kullandı',
        // Add defaults for other props here
    ];
    wp_localize_script( 'ema-modal-script', 'emaModalProps', $props );
}
add_action( 'wp_enqueue_scripts', 'ema_modal_enqueue_assets' );

// 4. Add the root element for React to mount onto
function ema_modal_add_root_element() {
    // Again, only on the public-facing site
    if ( is_admin() ) {
        return;
    }
    
    // Only add if we have a valid EMA URL
    $settings = get_option( 'ema_modal_settings' );
    $ema_url = isset( $settings['ema_url'] ) ? $settings['ema_url'] : '';
    
    if ( ! empty( $ema_url ) ) {
        echo '<div id="ema-modal-root"></div>';
    }
}
add_action( 'wp_footer', 'ema_modal_add_root_element' );

// 5. Add admin notice if plugin is not configured
function ema_modal_admin_notices() {
    $settings = get_option( 'ema_modal_settings' );
    $ema_url = isset( $settings['ema_url'] ) ? $settings['ema_url'] : '';
    
    if ( empty( $ema_url ) ) {
        $class = 'notice notice-warning';
        $message = 'EMA Modal Plugin is installed but not configured. Please <a href="' . admin_url( 'options-general.php?page=ema_modal' ) . '">configure your EMA URL</a> to activate the modal.';
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) );
    }
}
add_action( 'admin_notices', 'ema_modal_admin_notices' );

// 6. Plugin activation hook
function ema_modal_activate() {
    // Set default options if they don't exist
    if ( ! get_option( 'ema_modal_settings' ) ) {
        $default_options = [
            'ema_url' => '',
            'theme_color' => '#0066ff',
            'title' => 'EMA – Etkileşimli Müşteri Asistanı',
            'subtitle' => 'Ürünleri bulmanın, sorularınızı sormanın en kolay yolu',
            'brand_name' => '',
        ];
        add_option( 'ema_modal_settings', $default_options );
    }
}
register_activation_hook( __FILE__, 'ema_modal_activate' );

// 7. Plugin deactivation hook
function ema_modal_deactivate() {
    // Clean up if needed
}
register_deactivation_hook( __FILE__, 'ema_modal_deactivate' ); 